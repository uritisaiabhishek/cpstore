<section class="statistic_count grid grid-flow-row grid-cols-4 gap-3 p-5">
    <div class="bg-white p-5 rounded-md border-l-4 border-indigo-400">
        <h4 class="font-semibold text-xl capitalize">Products</h4>
        <p class="text-blue-500 font-bold text-2xl">0</p>
    </div>
</section>
<section class="grid grid-flow-row grid-cols-2">
    <div class="monthly_earnings"></div>
</section>