<footer class="bg-blue-200 p-5 text-center">
    Designed and developed by chronopegasus
</footer>