<?php
    define('SERVER_PATH',$_SERVER['DOCUMENT_ROOT'].'/cp-shop/public');
    define('SITE_PATH','http://localhost/cp-shop/public/');
?>