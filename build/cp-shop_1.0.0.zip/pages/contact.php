<section class="py-5">
    <div class="container mx-auto px-24">
        <div class="flex md:flex-row flex-col">
            <div class="w-1/2 p-3">
                <div class="bg-blue-200 p-5">raise a ticket</div>
            </div>
            <div class="w-1/2 p-3">
                <div class="bg-blue-200 p-5">contact us</div>
            </div>
        </div>
    </div>
</section>